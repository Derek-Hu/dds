  
import { Component } from 'react';

export default class NotFoundPage extends Component {
  componentDidMount() {
    console.log('mount');
  }
  render() {
    return <div>404</div>
  }
}
