export const SupportedCoins = ['DAI', 'USDC', 'USDT'];

export const CustomTabKey = 'dds-tabs'