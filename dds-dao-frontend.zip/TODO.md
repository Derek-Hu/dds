1. i18n-国际化
2. theme-双主题
3. Mobile版本
4. 界面实现
    Banner & 头部菜单
    Footer - 链接
    轮播图 - 图片&文字
    Why DDerivatives - 图标&文字
    How Trade动画 - 插件 & web3对接
    行情列表 - 图表 & web3对接
    Pool页面
    DDS页面 - Mining
    DDS页面 - Swap & Burn
    Broker页面
    Trade页面
    登录 - 与插件交互

周二、周四晚9:30
周日下午14:00
3月1日